/**
 * Print hello world.
 */
export default () => console.log('hello world')