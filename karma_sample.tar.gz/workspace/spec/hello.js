import hello from '../src/hello'

describe('hello', () => {

  it('says hello', () => {

    hello()

  })

})